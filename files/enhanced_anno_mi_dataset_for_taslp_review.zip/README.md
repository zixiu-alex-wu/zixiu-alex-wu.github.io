# AnnoMI: A Dataset of Expert-Annotated Counselling Dialogues (Enhanced)

## Introduction

Despite the remarkable growth of research in recent years on the analysis of counselling conversations through natural language processing methods, the potential of this field has been greatly limited by the lack of access to publicly available therapy dialogues, especially those with expert annotations. In this paper, we extend our previous introductory work of **_AnnoMI_** , where we released (https://github.com/uccollab/AnnoMI) the first publicly and freely available conversation dataset of 133 faithfully transcribed and expert-annotated demonstrations of high- and low-quality motivational interviewing (MI), an effective therapy strategy that evokes client motivation for positive change.

Specifically, we introduce a new, enhanced version of **_AnnoMI_**, as described in our paper _Creation, Analysis and Applications of AnnoMI, a Dataset of Expert-Annotated Counselling Dialogues_. This version has three new, expert-annotated utterance attributes, namely **Input (binary)**, **Reflection (binary)** and **Question** for each therapist utterance. For more details, please see the note below as well as the paper.

## Note to TASLP reviewers

This no-frills version of the enhanced **_AnnoMI_** is only for the TASLP reviewers of our manuscript --- _Creation, Analysis and Applications of AnnoMI, a Dataset of Expert-Annotated Counselling Dialogues_.

This version contains:

* Metadata of each transcript & utterance, e.g. the demonstrated MI quality and the URL of the original video
* Each utterance
* The annotation on each utterance: 
    **(Main) Therapist Behaviour**, **Input (binary)**, **Reflection (binary)** and **Question** for each therapist utterance, and 
    **Client Talk Type** for each client utterance

Please do **NOT** distribute this dataset. The final version of the dataset, with more information such as credits and the citation format, will be released on GitHub upon this paper's acceptance.

## Dataset Format

The dataset is stored in `dataset.csv`, in the same folder as this README. **Each row represents the information associated with an utterance.**

`dataset.csv` has the following columns:

* `transcript_id`: the unique numerical identifier of the conversation/transcript where this utterance belongs. Note that this identifier is NOT used for ordering, and it is only to distinguish between different conversations in the dataset.
* `mi_quality`: the MI quality demonstrated in the conversation/transcript where this utterance belongs. Either "high" or "low".
* `video_title`: the title of the original video of the conversation/transcript where this utterance belongs.
* `video_url`: the URL of the original video of the conversation/transcript where this utterance belongs.
* `topic`: the topic(s) of the conversation/transcript where this utterance belongs.
* `utterance_id`: the unique numerical index of this utterance. Note that this identifier IS ordering-sensitive, and the utterance whose `utterance_id` is $n$ is the $n$-th utterance of the conversation (identified by the `transcript_id` of this row) where this utterance belongs.
* `interlocutor`: the interlocutor of this utterance. Either "therapist" or "client".
* `timestamp`: the timestamp of this utterance w.r.t the original video of the conversation/transcript where this utterance belongs.
* `utterance_text`: the content of this utterance.
* `therapist_input_exists`: whether there is input from the therapist in this utterance. "n/a" if the utterance is a client utterance, otherwise one of ["True", "False"]
* `reflection_exists`: whether there is reflection from the therapist in this utterance. "n/a" if the utterance is a client utterance, otherwise one of ["True", "False"]
* `question`: the type of question from the therapist in this utterance. "n/a" if the utterance is a client utterance, otherwise one of ["no_question", "open", "closed"]
* `main_therapist_behaviour`: the (main) therapist behaviour of this utterance. "n/a" if the utterance is a client utterance, otherwise one of ["reflection", "question", "therapist\_input", "other].
* `client_talk_type`: the client talk type of this utterance. "n/a" if the utterance is a therapist utterance, otherwise one of ["change", "neutral", "sustain"].
        